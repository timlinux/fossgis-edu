# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/var/vhosts/pyqgis/builder/build/rasterscale/Ui_RasterScale.ui'
#
# Created: Thu Aug  5 04:06:46 2010
#      by: PyQt4 UI code generator 4.4.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_RasterScale(object):
    def setupUi(self, RasterScale):
        RasterScale.setObjectName("RasterScale")
        RasterScale.resize(400, 300)
        self.buttonBox = QtGui.QDialogButtonBox(RasterScale)
        self.buttonBox.setGeometry(QtCore.QRect(30, 240, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")

        self.retranslateUi(RasterScale)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), RasterScale.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), RasterScale.reject)
        QtCore.QMetaObject.connectSlotsByName(RasterScale)

    def retranslateUi(self, RasterScale):
        RasterScale.setWindowTitle(QtGui.QApplication.translate("RasterScale", "RasterScale", None, QtGui.QApplication.UnicodeUTF8))

